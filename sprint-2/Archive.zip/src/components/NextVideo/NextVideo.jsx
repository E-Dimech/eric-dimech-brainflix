// import React from 'react';

// const NextVideo = () => {
//     return (
//     <div className="video-build">
//             <div className="video-build__border" />
//             <h2 className="video-build__section-title">NEXT VIDEO</h2>
//             {videoArr}
//     </div>
//     )
// }

// export default NextVideo;