import React from 'react';
import Thumb from '../../assets/Images/Upload-video-preview.jpg';

import './Upload.scss';

const Upload = () => {
    return (
        <div className="upload">
            <h1>Upload Video</h1>

        </div>
    )
}


export default Upload;
